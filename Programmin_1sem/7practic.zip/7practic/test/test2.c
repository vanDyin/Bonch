#include <stdio.h>


void main()
{
    int array[2][2] = {{5, 1}, {2, 4}};

    printf("%d", *(array[1]));
}